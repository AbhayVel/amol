export class SortConfig {

  public  orderBy: number=1;  //? nullable optinal 
  public columnName: string='';
  public columnType?: string;
  public customLogic: any;
}


//?  is used as two type //safe navigation
