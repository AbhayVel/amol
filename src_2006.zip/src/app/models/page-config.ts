export class PageConfig {
  public pages: Array<number> = [];
  public currentPage: number = 1;
 

}



// Processing --> Srvice
// Model +Enitity +COnfig // factory 
