import { SortConfig } from './sort-config';

describe('SortConfig', () => {
  it('should create an instance', () => {
    expect(new SortConfig()).toBeTruthy();
  });
});
