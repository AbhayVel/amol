import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DeptListComponent } from './components/dept-list/dept-list.component';
import { SubjectListComponent } from './components/subject-list/subject-list.component';
import { UserEditReactiveComponent } from './components/user-edit-reactive/user-edit-reactive.component';
import { UserListComponent } from './components/user-list/user-list.component';

const routes: Routes = [

  { path: '', component: UserListComponent },
  {path: 'users' , component: UserListComponent },
  { path: 'depts', component: DeptListComponent },
  { path: 'subjects', component: SubjectListComponent },
  { path: 'user/edit/:id', component: UserEditReactiveComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
