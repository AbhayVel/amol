import { SubjectMasterPipe } from './subject-master.pipe';

describe('SubjectMasterPipe', () => {
  it('create an instance', () => {
    const pipe = new SubjectMasterPipe();
    expect(pipe).toBeTruthy();
  });
});
