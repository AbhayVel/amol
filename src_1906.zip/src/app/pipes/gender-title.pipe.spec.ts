import { GenderTitlePipe } from './gender-title.pipe';

describe('GenderTitlePipe', () => {
  it('create an instance', () => {
    const pipe = new GenderTitlePipe();
    expect(pipe).toBeTruthy();
  });
});
