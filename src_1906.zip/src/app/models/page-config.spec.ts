import { PageConfig } from './page-config';

describe('PageConfig', () => {
  it('should create an instance', () => {
    expect(new PageConfig()).toBeTruthy();
  });
});
