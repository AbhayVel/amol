import { FilterConfig } from './filter-config';

describe('FilterConfig', () => {
  it('should create an instance', () => {
    expect(new FilterConfig()).toBeTruthy();
  });
});
