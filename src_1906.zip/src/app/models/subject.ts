export class Subject {

  public id: number = 0;
  public name: string = '';
}
