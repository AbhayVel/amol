import { PopupConfig } from './popup-config';

describe('PopupConfig', () => {
  it('should create an instance', () => {
    expect(new PopupConfig()).toBeTruthy();
  });
});
