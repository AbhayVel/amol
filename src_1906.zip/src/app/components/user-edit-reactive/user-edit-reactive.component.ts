import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { QMathService } from '../../services/qmath.service';

@Component({
  selector: 'qdn-user-edit-reactive',
  templateUrl: './user-edit-reactive.component.html',
  styleUrls: ['./user-edit-reactive.component.css']
})
export class UserEditReactiveComponent implements OnInit {

  constructor(private ac: ActivatedRoute,

    private router: Router,
    private qm: QMathService
    

  ) {
    console.log("I am in COnstructor");

  }

  id = '';
  name = '';

  result=''

  ngOnInit(): void {

    console.log("I am in ngOnInit");
    //this.id = this.ac.snapshot.params["id"];
    //this.name = this.ac.snapshot.queryParams['name'];

    this.ac.params.subscribe((p) => {
      this.id = p["id"];
      this.name = this.ac.snapshot.queryParams['name'];
    })


  }


  async saveObs(a: any, b: any) {
    // this.result = (+a + +b).toString();
    console.log("I m before call Obs + sub")
    this.qm.divObs(a, b).subscribe((result) => {
      console.log("I m in result call Obs + sub")
      this.result = result;
    }, (error) => {

        console.log("I m in error call promise + then")
        alert(error);
    })

    console.log("I m after call obs + subs")
   
  }


  timePro = '';
  timeObs = '';
  showTime() {
    this.qm.showTimePro().then((res) => {
      this.timePro = res;
    })


    this.qm.showTimeObs().toPromise().then((res) => {
      this.timeObs = res;
    })
  }

  changeUrl(val: any) {
    this.router.navigate(['user', 'edit', val], { queryParams: { name: this.name + val }, skipLocationChange: false });

  }

 async save(a: any, b: any) {
   // this.result = (+a + +b).toString();

   //console.log("I m before call promise + await")
  //   this.result = await this.qm.div(a, b);
   //console.log("I m after call promise + await")

   console.log("I m before call promise + then")
   this.qm.div(a, b).then((result) => {
     console.log("I m in result call promise + then")
     this.result = result;
   }).catch((error) => {
     console.log("I m in error call promise + then")
     alert(error);
     this.result = '';
   });
   console.log("I m after call promise + then")

   // this.result = this.qm.div(a, b);
//    this.router.navigate(['user', 'edit', val], { queryParams: { name: this.name+val }, skipLocationChange: false });

  }

}
