import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { FilterConfig } from '../../models/filter-config';
import { PopupConfig } from '../../models/popup-config';
import { SortConfig } from '../../models/sort-config';
import { Subject } from '../../models/subject';
import { User } from '../../models/user';
import { PopupComponent } from '../../modules/shared/popup/popup.component';
import { GenderTitlePipe } from '../../pipes/gender-title.pipe';
import { SubjectMasterPipe } from '../../pipes/subject-master.pipe';
import { FirstService } from '../../services/first.service';
import { GridServiceService } from '../../services/grid-service.service';
import { SharedUtility } from '../../utilities/shared-utility';


@Component({
  selector: 'qdn-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css'],
  
})
export class UserListComponent implements OnInit {

  //insatance variable can be access from Html

  //insatance variable can be access from Html

    @ViewChild('popRef')
  popRef: PopupComponent = new PopupComponent;

  user = new User();

  gs: GridServiceService;
  popupConfig: PopupConfig = PopupConfig.createPopupConfig({
    header: 'Edit User',
    closeButtonText: 'Cancel',
    isHeader: true
  })

  subjectArray: Array<Subject> = [
    {
      id: 1,
      name: 'Angular'
    },
    {
      id: 2,
      name: '.net'
    },
    {
      id: 3,
      name: 'Selenium'
    },
    {
      id: 4,
      name: 'Java'
    }

  ]

  userArray : Array<User> = [
    {
      id: 1,
      name: {
        firstName: "Amol",
        lastName: "F"

      },
      gender: 'M',
      doj: '25/04/2021',
      subject: 1,
      fees: 25000,
      status: 'aCtive'
    },
    {
      id: 2,
      name: {
        firstName: "Yogesh",
        lastName : "L"

      },
      gender: 'M',
      doj: '12/04/2021',
      subject: 2,
      fees: 35000,
      status: 'active'
    },
    {
      id: 3,
      name: {
        firstName: "Kaustubh",
        lastName: "k"

      },
      gender: 'M',
      doj: '12/02/2021',
      subject: 2,
      fees: 20000,
      status: 'active'
    },
    {
      id: 4,
   name:  {
      firstName: "Komal",
      lastName: "k"

    },
      gender: 'F',
      doj: '20/01/2012',
      subject: 3,
      fees: 30000,
      status: 'iNactive'
    },
    {
      id: 5,
      name: {
        firstName: "Amruta",
        lastName: "V"

      },
      gender: 'F',
      doj: '10/01/2018',
      subject: 3,
      fees: 30000,
      status: 'inactive'
    },
    {
      id: 6,
      name: {
        firstName: "XXX",
        lastName: "Y"

      },
      gender: 'O',
      doj: '10/01/2021',
      subject: 4,
      fees: 30000,
      status: 'inactive'
    }

  ]


  sortConfig: SortConfig = {
    orderBy: 1,
    columnName: 'id',
    columnType: 'num',
    customLogic: undefined
  }



  filterConfig: FilterConfig<User> = {
    data: [],
    rows: [],
    pages: [],
    currentPage: 1,
    rowPerPage: 2,
    filter: {
      id: {
        columnName: "id",
        columnValue: "",
        columnType: "num",
        customLogic: undefined
      },
      gender: {
        columnName: "gender",
        columnValue: "",
        columnType: "cistr",
        customLogic: undefined
      },
      subject: {
        columnName: "subject",
        columnValue: "",
        columnType: "num",
        customLogic: undefined
      },
      feesGte: {
        columnName: "fees",
        columnValue: "",
        columnType: "numGte",
        customLogic: undefined
      },
      feesLte: {
        columnName: "fees",
        columnValue: "",
        columnType: "numLte",
        customLogic: undefined
      },
      dojGte: {
        columnName: "doj",
        columnValue: "",
        columnType: "dateGte",
        customLogic: undefined
      },
      dojLte: {
        columnName: "doj",
        columnValue: "",
        columnType: "dateLte",
        customLogic: undefined
      },
      status: {
        columnName: "status",
        columnValue: "",
        columnType: "cistrematch",
        customLogic: undefined
      },
      name: {
        columnName: "name",
        columnValue: "",
        columnType: "xx",
        customLogic: SharedUtility.nameSearch
      },
    }
  }



  add() {
    this.popupConfig.header = "Add User";
    this.popRef.show();
  }

  editR(u: User) {
   this.router.navigate(['user', 'edit', u.id], { queryParams: { name: u.name.firstName}  , skipLocationChange  : false });
    ///user/edit/12;

  //  this.router.navigateByUrl(`user/edit/${u.id}?name=${u.name.firstName}`, { skipLocationChange : true });
  }

  edit(u: User) {
     //this.popupConfig.isShow = true;
     //this.popupConfig = { ...this.popupConfig };
    this.user = u;
    this.popupConfig.header = "Edit User";
     this.popRef.show();
  }
  show() {
    this.first.count = this.first.count + 1;
  console.log(this.first.count);

  }

 
  constructor(gs: GridServiceService,
    private first: FirstService,
    private router: Router

  ) {
    this.gs = gs;

  }

  popupCLose() {
    console.log("I am in CLose");
  }

  search(columnName: string,columnValue: any): any {
    this.filterConfig.filter[columnName].columnValue = columnValue;
    this.gs.execute(this.filterConfig, this.sortConfig);
  }


  pageChange(p: number) {
    this.gs.execute(this.filterConfig, this.sortConfig);
  }
   

  sortData(columnName: string, columnType: string) {
    this.sortConfig.orderBy = this.sortConfig.orderBy * -1;
    this.sortConfig.columnName = columnName;
    this.sortConfig.columnType = columnType;


    if (columnName == 'name') {
      this.sortConfig.customLogic = SharedUtility.nameSort;
    } else if (columnName == 'subject') {
      this.sortConfig.customLogic = SharedUtility.subjectNameSort;
    }  else {
      this.sortConfig.customLogic = undefined;
    }

    this.gs.execute(this.filterConfig, this.sortConfig);
    //let orderBy = this.orderBy;



      // this.userArray.sort((e1: any, e2: any)=>{  ///  callback es 5  //Arrow function is available in es 6 and above
      //   if (columnType == 'cistr') {
      //     return e1[columnName].toLowerCase() > e2[columnName].toLowerCase() ? this.orderBy : -1 * this.orderBy;
      //   } else if (columnType == 'date') {

      //     let val1 = this.convertDate( e1[columnName]);
      //     let val2 = this.convertDate(e2[columnName]);


      //     return val1 > val2 ? this.orderBy : -1 * this.orderBy;
      //   } else {
      //     return e1[columnName] > e2[columnName] ? this.orderBy : -1 * this.orderBy;
      //   }
         
      //});


    //if (this.orderBy == -1) {
    //  this.userArray.sort(function (e1: any, e2: any) {

    //    return e1[columnName] > e2[columnName] ? 1 : -1;
    //  });
    //} else {

    //  this.userArray.sort(function (e1: any, e2: any) {

    //    return e1[columnName] > e2[columnName] ? -1 : 1;
    //  });
    //}
      

    //if (columnName == 'id') {
    //  this.userArray.sort(function (e1, e2) {

    //    return e1.id > e2.id ? -1 : 1;
    //  });
    //} else if (columnName == 'name') {
    //  this.userArray.sort(function (e1, e2) {

    //    return e1.name > e2.name ? -1 : 1;
    //  });
    //} else if (columnName == 'gender') {
    //  this.userArray.sort(function (e1, e2) {

    //    return e1.gender > e2.gender ? -1 : 1;
    //  });
    //}
   
     
  }

  ngOnInit(): void {

    this.filterConfig.data = this.userArray;
    this.filterConfig.rows = this.userArray;
    this.gs.execute(this.filterConfig, this.sortConfig);
  }

}
