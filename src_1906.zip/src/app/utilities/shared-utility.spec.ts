import { SharedUtility } from './shared-utility';

describe('SharedUtility', () => {
  it('should create an instance', () => {
    expect(new SharedUtility()).toBeTruthy();
  });
});
